// public class ChasePlayerNode : Node
// {
//     private BossAI boss;

//     public ChasePlayerNode(BossAI boss)
//     {
//         this.boss = boss;
//     }

//     public override NodeState Evaluate()
//     {
//         boss.MoveTowardsPlayer();
//         return NodeState.Running;
//     }
// }
